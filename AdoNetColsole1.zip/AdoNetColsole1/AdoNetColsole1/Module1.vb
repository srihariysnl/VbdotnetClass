﻿Imports System.Data.SqlClient

Module Module1

    Sub Main()

        Dim con As SqlConnection = New SqlConnection()
        con.ConnectionString = "Data Source=SRIHARI-PC\SRIHARIPC;Initial Catalog=College;User ID=sa;Password=ysnl;"
        con.Open()

        Console.WriteLine("Enter City : ")
        Dim city As String = Console.ReadLine

        Dim cmd As SqlCommand = New SqlCommand("select * from student where address='" & city & "'", con)
        Dim dr As SqlDataReader = cmd.ExecuteReader()
        'con.Close()
        While (dr.Read())
            Console.WriteLine(dr(0).ToString & "||" & dr(1).ToString & "||" & dr(2).ToString)
        End While
        dr.Close()

        Console.WriteLine("Enter Student Id, Name,Address & Mobile : ")

        Dim StudId As String = Console.ReadLine
        Dim SName As String = Console.ReadLine
        Dim address As String = Console.ReadLine
        Dim mobile As String = Console.ReadLine

        'Dim insQuery = "insert into Student values(" & StudId & ",'" & SName & "','" & address & "','" & mobile & "')"
        Dim insCmd As New SqlCommand()
        insCmd.CommandText = "insert into student values(@sid,@sname,@address,@mobile)"
        insCmd.Connection = con

        insCmd.Parameters.Add(New SqlParameter("@sid", StudId))
        insCmd.Parameters.Add(New SqlParameter("@sname", SName))
        insCmd.Parameters.Add(New SqlParameter("@address", address))
        insCmd.Parameters.Add(New SqlParameter("@mobile", mobile))


        Dim count As Integer = insCmd.ExecuteNonQuery
        If count >= 1 Then
            Console.WriteLine("1 record inserted")
        End If
        con.Close()

        Console.ReadLine()



    End Sub

End Module
