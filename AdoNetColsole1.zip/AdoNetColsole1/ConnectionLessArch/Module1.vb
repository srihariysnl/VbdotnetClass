﻿Imports System.Data.SqlClient
Imports System.Data

Module Module1

    Sub Main()

        Dim con As New SqlConnection("Data Source= SRIHARI-PC\SRIHARIPC;Initial Catalog=College;User ID=sa;Password=ysnl")
        con.Open()

        Dim da As New SqlDataAdapter("select * from student", con)
        Dim cb As New SqlCommandBuilder(da)
        Dim ds As New DataSet()

        If (con.State = ConnectionState.Open) Then

            da.Fill(ds, "student")
            con.Close()
            Dim dt As DataTable = ds.Tables("student")
            AllRecords(dt)

            Console.WriteLine("Enter Student Id, Name,Address & Mobile : ")
            Dim newRow = dt.NewRow()
            newRow(0) = Console.ReadLine()
            newRow(1) = Console.ReadLine()
            newRow(2) = Console.ReadLine()
            newRow(3) = Console.ReadLine()
            dt.Rows.Add(newRow)

            con.Open()
            da.Update(dt)
            con.Close()

            AllRecords(dt)
        End If
        Console.ReadLine()


    End Sub

    Public Sub AllRecords(dt As DataTable)
        For Each col As DataColumn In dt.Columns
            Console.Write(col.ColumnName & "||")
        Next
        Console.WriteLine(vbNewLine & "------------------------------------------")
        For Each dr As DataRow In dt.Rows
            Console.WriteLine(dr.ItemArray(0).ToString() & "||" _
                             & dr.ItemArray(1).ToString() & "||" _
                             & dr.ItemArray(2).ToString() & "||" _
                             & dr.ItemArray(3).ToString())
        Next


    End Sub

End Module
