﻿Module Module1

    Sub Main()

        Dim obj As SealedClass = New SealedClass
        obj.Display()

        ' Dim num As Integer

        Console.ReadLine()

    End Sub

End Module
