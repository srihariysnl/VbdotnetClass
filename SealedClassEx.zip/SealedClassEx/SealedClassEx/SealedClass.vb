﻿Public NotInheritable Class SealedClass

    Public Sub Display()
        Console.WriteLine("I am from sealed class.")
    End Sub

End Class

'Public Class TestDeriv
'    Inherits SealedClass


'End Class
