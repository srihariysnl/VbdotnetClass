﻿Public Structure Student
    Private rno As Integer
    Private name As String
    Private address As String

    Public Sub ReadData()
        Console.WriteLine("Enter student data : ")
        rno = Integer.Parse(Console.ReadLine)
        name = Console.ReadLine()
        address = Console.ReadLine()
    End Sub

    Public Sub Display()
        Console.WriteLine("Student Data : ")
        Console.WriteLine("Rno : " & rno)
        Console.WriteLine("Name : " & name)
        Console.WriteLine("Address : " & address)
    End Sub
End Structure

Module Module1

    Sub Main()

        Dim stud1 As Student = New Student
        stud1.ReadData()


        Dim stud2 As Student = stud1
        stud2.Display()

        stud2.ReadData()

        stud1.Display()
        stud2.Display()


        Console.ReadLine()



    End Sub

End Module
