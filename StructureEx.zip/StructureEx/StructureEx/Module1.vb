﻿Public Structure Student
    Public rno As Integer
    Public name As String
    Public address As String
End Structure

Module Module1

    Sub Main()

        Dim stud As Student
        Console.WriteLine("Enter student data : ")
        stud.rno = Integer.Parse(Console.ReadLine)
        stud.name = Console.ReadLine()
        stud.address = Console.ReadLine()

        Console.WriteLine("Student Data : ")
        Console.WriteLine("Rno : " & stud.rno)
        Console.WriteLine("Name : " & stud.name)
        Console.WriteLine("Address : " & stud.address)

        Console.ReadLine()


    End Sub

End Module
