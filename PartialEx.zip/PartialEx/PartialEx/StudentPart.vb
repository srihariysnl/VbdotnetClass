﻿Partial Public Class Student

    Private rno As Integer
    Private name As String
    Private address As String

End Class
