﻿Partial Public Class Student
    Public Sub Display()
        Console.WriteLine("Student Data : ")
        Console.WriteLine("Rno : " & rno)
        Console.WriteLine("Name : " & name)
        Console.WriteLine("Address : " & address)
    End Sub

End Class
