﻿Partial Public Class Student
    Public Sub ReadData()
        Console.WriteLine("Enter student data : ")
        rno = Integer.Parse(Console.ReadLine)
        name = Console.ReadLine()
        address = Console.ReadLine()
    End Sub

End Class
