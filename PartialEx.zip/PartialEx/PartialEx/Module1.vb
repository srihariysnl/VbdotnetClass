﻿Module Module1

    Sub Main()

        Dim obj As Student = New Student()
        obj.ReadData()
        obj.Display()
        Console.ReadLine()

    End Sub

End Module
