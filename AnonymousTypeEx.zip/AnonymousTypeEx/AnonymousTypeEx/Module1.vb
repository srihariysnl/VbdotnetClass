﻿'Class Company
'    Public Property Name As String
'    Public Property Location As String
'    Public Property Grader As Integer
'End Class

Module Module1
    Sub Main()

        Dim companyDetails = New With {.Name = "Yaagno Tech", .Location = "Chennai", .Grade = 5}
        Console.WriteLine("Company Name : " & companyDetails.Name)
        Console.WriteLine("Company Location : " & companyDetails.Location)
        Console.WriteLine("Company Grade : " & companyDetails.Grade)

        'Dim compDet As Company = New Company() With {
        '        .Name = "Yaagno Tech",
        '        .Location = "Chennai",
        '        .Grader = 5
        '    }

        Console.ReadLine()

    End Sub

End Module
