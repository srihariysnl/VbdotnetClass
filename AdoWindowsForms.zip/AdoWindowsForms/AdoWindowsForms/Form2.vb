﻿Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Data

Public Class Form2

    Dim constr = ConfigurationManager.ConnectionStrings("constrCollege").ConnectionString
    Dim con As SqlConnection
    Dim da As SqlDataAdapter
    Dim ds As DataSet

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        con = New SqlConnection(constr)
        con.Open()
        ds = New DataSet()
        da = New SqlDataAdapter("select * from student", con)

        da.Fill(ds)
        con.Close()

        gvStudent.DataSource = ds.Tables(0)

    End Sub
End Class