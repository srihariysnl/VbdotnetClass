﻿Public Class BnExampleDesignTime
    Private Sub BnExampleDesignTime_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CollegeDataSet.Student' table. You can move, or remove it, as needed.
        Me.StudentTableAdapter.Fill(Me.CollegeDataSet.Student)

    End Sub
End Class