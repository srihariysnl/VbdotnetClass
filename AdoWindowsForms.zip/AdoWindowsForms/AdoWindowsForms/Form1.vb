﻿Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Data

Public Class Form1

    Dim constr = ConfigurationManager.ConnectionStrings("constrCollege").ConnectionString
    Dim con As SqlConnection
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Dim dt As DataTable
    Dim cmdBuilder As SqlCommandBuilder

    Dim inx As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        con = New SqlConnection(constr)
        con.Open()
        ds = New DataSet()
        da = New SqlDataAdapter("select * from student", con)
        cmdBuilder = New SqlCommandBuilder(da)
        da.Fill(ds)
        con.Close()

        dt = ds.Tables(0)
        inx = 0

        Dim dr As DataRow = dt.Rows(inx)
        Display(dr)
    End Sub

    Private Sub Display(dr As DataRow)
        txtStudId.Text = dr.ItemArray(0).ToString()
        txtSudName.Text = dr(1).ToString()
        txtAddress.Text = dr(2).ToString()
        txtMobile.Text = dr(3).ToString()
    End Sub

    Private Sub btnFirst_Click(sender As Object, e As EventArgs) Handles btnFirst.Click
        inx = 0
        Display(dt.Rows(inx))
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        inx += 1
        If inx >= dt.Rows.Count Then
            inx = dt.Rows.Count - 1
        End If
        Display(dt.Rows(inx))
    End Sub

    Private Sub btnLast_Click(sender As Object, e As EventArgs) Handles btnLast.Click
        inx = dt.Rows.Count - 1
        Display(dt.Rows(inx))
    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        inx -= 1
        If inx < 0 Then
            inx = 0
        End If
        Display(dt.Rows(inx))
    End Sub

    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        ClearAll()
    End Sub

    Private Sub ClearAll()
        txtStudId.Clear()
        txtSudName.Clear()
        txtAddress.Clear()
        txtMobile.Clear()

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim dr As DataRow = dt.NewRow()
        dr(0) = txtStudId.Text
        dr(1) = txtSudName.Text
        dr(2) = txtAddress.Text
        dr(3) = txtMobile.Text
        dt.Rows.Add(dr)

        con.Open()
        da.Update(dt)
        con.Close()

    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim dr As DataRow = dt.Rows(inx)
        dr(0) = txtStudId.Text
        dr(1) = txtSudName.Text
        dr(2) = txtAddress.Text
        dr(3) = txtMobile.Text
        con.Open()
        da.Update(dt)
        con.Close()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim dr As DataRow = dt.Rows(inx)
        dr.Delete()
        con.Open()
        da.Update(dt)
        con.Close()

    End Sub

    Private Sub btnAllData_Click(sender As Object, e As EventArgs) Handles btnAllData.Click
        Dim StudentData As Form2 = New Form2
        StudentData.Show()
    End Sub

    Private Sub btnBn_Click(sender As Object, e As EventArgs) Handles btnBn.Click
        Dim bnForm As New Form3()
        bnForm.Show()
    End Sub
End Class
