﻿Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Data
Public Class Form3
    Dim constr = ConfigurationManager.ConnectionStrings("constrCollege").ConnectionString
    Dim con As SqlConnection
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        con = New SqlConnection(constr)
        con.Open()
        ds = New DataSet()
        da = New SqlDataAdapter("select * from student", con)

        da.Fill(ds, "Student")

        Dim bsStudentData As New BindingSource()
        bsStudentData.DataSource = ds
        bsStudentData.DataMember = "Student"

        bnStudentData.BindingSource = bsStudentData

        txtStudId.DataBindings.Add("Text", bsStudentData, "StudId")
        txtSudName.DataBindings.Add("Text", bsStudentData, "SName")
        txtAddress.DataBindings.Add("Text", bsStudentData, "Address")
        txtMobile.DataBindings.Add("Text", bsStudentData, "Mobile")


    End Sub
End Class